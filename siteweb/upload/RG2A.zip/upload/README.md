# RG2A
Notre projet consiste a créer une simulation d'exploration où :
Des robots doivent être capable de trouver le plus rapidement possible, même
dans les pires conditions, une cible positionnée dans une arène.

## Pré-requis
Posséder le logiciel make permettant exécuter le Makefile

## Démarrage
* make run

## Auteurs
* **Gabin REDJEB**
* **Alexandre GALLARDO**
* **Akram SAADI**
